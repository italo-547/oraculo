import type { Dirent } from 'fs';
import type { NodePath, TraverseOptions } from '@babel/traverse';
import type { Node as BabelNode, AssignmentExpression, ExportNamedDeclaration, VariableDeclarator, FunctionDeclaration, FunctionExpression, ArrowFunctionExpression, StringLiteral, ImportDeclaration, CallExpression, ExportAllDeclaration } from '@babel/types';
export type { BabelNode, NodePath, AssignmentExpression, ExportNamedDeclaration, VariableDeclarator, FunctionDeclaration, FunctionExpression, ArrowFunctionExpression, StringLiteral, ImportDeclaration, CallExpression, ExportAllDeclaration, TraverseOptions, };
export interface FileEntry {
    relPath: string;
    content: string | null;
    fullPath?: string;
}
export interface BaseFileEntry extends FileEntry {
    fullPath: string;
    origem?: 'local' | 'remoto' | 'gerado';
    ultimaModificacao?: number;
}
export interface FileEntryWithAst<N extends BabelNode = BabelNode> extends BaseFileEntry {
    ast: N | null;
}
export type FileMap = Record<string, BaseFileEntry>;
export type FileMapWithAst<N extends BabelNode = BabelNode> = Record<string, FileEntryWithAst<N>>;
export interface SnapshotItem {
    hash: string;
    linhas: number;
    amostra: string;
}
export type Snapshot = Record<string, SnapshotItem>;
export interface RegistroIntegridade {
    arquivo: string;
    hash: string;
}
export interface DiffResultado {
    removidos: string[];
    adicionados: string[];
    alterados: string[];
}
export declare enum IntegridadeStatus {
    Criado = "baseline-criado",
    Aceito = "baseline-aceito",
    Ok = "ok",
    AlteracoesDetectadas = "alteracoes-detectadas"
}
export interface ResultadoIntegridade {
    status: IntegridadeStatus;
    timestamp: string;
    totalArquivos?: number;
}
export interface ResultadoVerificacao {
    corrompidos: string[];
    verificados: number;
}
export declare class GuardianError extends Error {
    detalhes: string[];
    constructor(erros: string[]);
}
export type OcorrenciaNivel = 'erro' | 'aviso' | 'info' | 'sucesso';
export interface Ocorrencia {
    tipo: string;
    nivel: OcorrenciaNivel;
    mensagem: string;
    arquivo: string;
    relPath: string;
    linha: number;
    fullPath?: string;
    coluna?: number;
    trecho?: string;
    origem?: string;
    resolucao?: string;
    severidade?: number;
    codigo?: string;
    tipoOcorrencia?: string;
    filePath?: string;
}
export type TecnicaAplicarResultado = Ocorrencia[] | Ocorrencia | null | undefined;
export type TestFunction = (relPath: string) => boolean;
export interface Tecnica {
    nome: string;
    test?: TestFunction;
    global?: boolean;
    aplicar(src: string, relPath: string, ast: BabelNode | null, fullPath?: string, contexto?: ContextoExecucao): TecnicaAplicarResultado | Promise<TecnicaAplicarResultado>;
}
export interface ContextoExecucao {
    baseDir: string;
    arquivos: FileEntryWithAst[];
    ambiente: Record<string, unknown>;
    guardian?: ResultadoIntegridade;
}
export interface ResultadoInquisicao {
    totalArquivos: number;
    ocorrencias: Ocorrencia[];
    arquivosAnalisados: string;
    fileEntries: FileEntryWithAst[];
    timestamp: number;
    duracaoMs: number;
    guardian?: ResultadoIntegridade;
    arquivosOrfaosDetectados?: string[];
}
export interface ScanOptions {
    includeContent?: boolean;
    filter?: (relPath: string, entry: Dirent) => boolean;
    onProgress?: (msg: string) => void;
}
export type TipoProjeto = 'desconhecido' | 'landing' | 'api' | 'lib' | 'cli' | 'fullstack' | 'monorepo';
export interface SinaisProjeto {
    temPages?: boolean;
    temComponents?: boolean;
    temControllers?: boolean;
    temApi?: boolean;
    temExpress?: boolean;
    temSrc?: boolean;
    temCli?: boolean;
    temPrisma?: boolean;
    temPackages?: boolean;
    ehFullstack?: boolean;
    ehMonorepo?: boolean;
}
export interface DiagnosticoProjeto {
    tipo: TipoProjeto;
    sinais: Array<keyof SinaisProjeto>;
    confiabilidade: number;
}
export interface ArquivoFantasma {
    arquivo: string;
    diasInativo: number;
    referenciado?: boolean;
}
export interface Pendencia {
    arquivo: string;
    motivo: string;
    detectedAt: number;
    scheduleAt: number;
}
export interface HistoricoItem {
    arquivo: string;
    movidoEm: string;
    motivo: string;
}
export type Contador = Record<string, number>;
export type Estatisticas = Record<'requires' | 'consts' | 'exports', Contador>;
export interface Alinhamento {
    arquivo: string;
    atual: string;
    ideal: string | null;
}
export interface Config {
    DEV_MODE: boolean;
    AUTOANALISE_CONCURRENCY: number;
    GUARDIAN_ENABLED: boolean;
    GUARDIAN_ENFORCE_PROTECTION: boolean;
    GUARDIAN_BASELINE: string;
    GUARDIAN_ALLOW_ADDS: boolean;
    GUARDIAN_ALLOW_CHG: boolean;
    GUARDIAN_ALLOW_DELS: boolean;
    REPORT_SILENCE_LOGS: boolean;
    REPORT_EXPORT_ENABLED: boolean;
    REPORT_OUTPUT_DIR: string;
    ZELADOR_STATE_DIR: string;
    ZELADOR_ABANDONED_DIR: string;
    ZELADOR_PENDING_PATH: string;
    ZELADOR_REACTIVATE_PATH: string;
    ZELADOR_HISTORY_PATH: string;
    ZELADOR_REPORT_PATH: string;
    ZELADOR_GHOST_INACTIVITY_DAYS: number;
    ZELADOR_IGNORE_PATTERNS: string[];
    ZELADOR_LINE_THRESHOLD: number;
    ANALISTA_THRESHOLD_CONST_REQUIRE: number;
    ANALISTA_USAGE_TOP_N: number;
    BOT_VALIDATOR_RULES: {
        name: string;
        missingType: string;
        resolucao: string;
    }[];
    CORRETOR_ESTRUTURA_AUTO_FIX: boolean;
    STRUCTURE_LAYERS: Record<string, string>;
    STRUCTURE_CONCURRENCY: number;
    STRUCTURE_AUTO_FIX: boolean;
    STRUCTURE_PLUGINS: any[];
    PLUGINS_ENABLED: boolean;
    PLUGINS_DIR: string;
    SCANNER_EXTENSOES_COM_AST: string[];
    STATE_DIR: string;
    GHOST_FILE_INACTIVITY_DAYS: number;
    DIR_ABANDONADOS: string;
    PATH_PENDENTES: string;
    PATH_REATIVAR: string;
    PATH_HISTORICO: string;
    PATH_RELATORIO: string;
    VIGIA_TOP_N: number;
}