// src/guardian/index.ts
// 🎯 Ponto central de exportação do subsistema Guardian
export { scanSystemIntegrity } from './sentinela.js';
export { vigiaOculta } from './vigiaOculto.js';
export { verificarRegistros } from './verificador.js';
export { carregarBaseline, salvarBaseline } from './baseline.js';
export { diffSnapshots, verificarErros } from './diff.js';
export { BASELINE_PATH, REGISTRO_VIGIA_CAMINHO_PADRAO, ALGORITMO_HASH } from './constantes.js';
