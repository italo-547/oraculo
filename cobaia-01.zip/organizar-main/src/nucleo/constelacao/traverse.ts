import traverseModule from '@babel/traverse';
/**
 * Traverse do Babel com tipagem explícita.
 */
export const traverse = traverseModule.default;
