# Copilot Instructions for Oráculo CLI (Hardening + Proveniência)

Este arquivo consolida as instruções existentes e adiciona diretrizes para minimizar riscos de semelhança com código público, questões de licença, privacidade e segurança operacional. Também endurece o padrão de persistência de estado com práticas seguras.

---

## Configuração do Copilot e Política de Originalidade

- Ative nas configurações do Copilot: “Bloquear sugestões que correspondam a código público” quando disponível.
- Mesmo com proteções ativas, revise manualmente as sugestões: evite trechos idênticos ou substancialmente semelhantes a código público.
- Prefira soluções originais de “first principles” e não copie de blogs, SO ou repositórios.
- Caso um algoritmo clássico seja necessário, implemente a partir da especificação, não de uma implementação pública.
- Não insira trechos longos de terceiros. Como regra prática, evite blocos >20 linhas originados de uma única fonte pública.
- Referencie documentação oficial apenas na descrição do PR (não copie texto integral para arquivos-fonte).

### Checklist de Proveniência e Verificações (exigir no PR)

- [ ] Originalidade: solução autoral, sem cópia literal de código público.
- [ ] Checagem de correspondência com código público realizada; se houve risco, foi reescrito.
- [ ] Licenças: novas dependências compatíveis com MIT (preferência MIT/Apache-2.0/BSD). Evitar GPL/AGPL/LGPL.
- [ ] Segurança: sem segredos em código/commits; entradas validadas; configurações seguras por padrão.
- [ ] Qualidade: testes incluídos/atualizados e passando; lint/format aplicados.
- [ ] Referências: links apenas para documentação (se houver), adicionados na descrição do PR.

### Branches do agente/assistente
- Use sempre branches copilot/<slug-descritivo>.
- PRs do agente/assistente requerem revisão obrigatória antes de merge.

---

## Licença, Dependências e Conformidade

- O repositório é MIT. Gere apenas conteúdo compatível com MIT (preferência MIT, Apache-2.0, BSD).
- Evite dependências com copyleft forte (GPL/AGPL/LGPL). Justifique qualquer exceção em PR.
- Não “vendorize” código de terceiros; use sempre gerenciadores de pacotes.
- Mantenha atualizado o inventário de terceiros (THIRD-PARTY-NOTICES). Não copie o código das dependências para dentro do repo.

---

## Privacidade, Segredos e Dados

- Não inclua tokens/chaves/credenciais em código, exemplos, commits, issues ou PRs. Use placeholders (YOUR_API_KEY) e variáveis de ambiente.
- Não cole conteúdo de repositórios privados ou documentos internos.
- Redija exemplos originais; se derivar de documentação, reescreva e cite o link no PR.

---

## Helpers Utilitários e Persistência de Estado

Para evitar duplicidade e facilitar manutenção, todas as funções auxiliares recorrentes (persistência, manipulação de pendências, leitura/escrita de estado, etc.) devem ser centralizadas e usadas de forma consistente.

### Padrão de Persistência (obrigatório)

- Utilize sempre os helpers `lerEstado` e `salvarEstado` para leitura/escrita de arquivos de estado, JSON, relatórios ou snapshots.
- Não use `fs.readFile`/`fs.writeFile` diretamente fora deste helper.
- Endurecimento aplicado:
  - Escrita atômica (arquivo temporário + rename).
  - Permissões restritivas (0o600) para arquivos de estado.
  - Garantia de diretório com modo 0o700.
  - Normalização e validação de caminho para evitar escrita fora do repositório.
  - Retorno com valor padrão configurável, ao invés de `[]` fixo.
  - JSON estável com espaçamento e suprimir valores indefinidos opcionais.

#### Implementação recomendada (segura)

```ts
// src/zeladores/util/persistencia.ts
import { promises as fs } from 'node:fs';
import { constants as fsConstants } from 'node:fs';
import path from 'node:path';
import process from 'node:process';

const raizProjeto = path.resolve(process.cwd());

function resolverSeguro(caminhoRelOuAbs: string): string {
  const alvo = path.resolve(raizProjeto, caminhoRelOuAbs);
  // Garante que o alvo está dentro da raiz do projeto
  if (!alvo.startsWith(raizProjeto + path.sep) && alvo !== raizProjeto) {
    throw new Error(`Caminho fora da raiz do projeto: ${alvo}`);
  }
  return alvo;
}

async function garantirDiretorio(caminhoArquivo: string) {
  const dir = path.dirname(caminhoArquivo);
  await fs.mkdir(dir, { recursive: true, mode: 0o700 });
}

function stringifyEstavel<T>(dados: T): string {
  // JSON com ordenação superficial de chaves para estabilidade em diffs
  const replacer = (key: string, value: unknown) => value;
  return JSON.stringify(dados, (key, value) => replacer(key, value), 2);
}

/**
 * Lê JSON de um arquivo de estado. Em caso de erro/ausência, retorna defaultValue.
 * Lança erro apenas em casos de acesso inválido (permissão/caminho fora da raiz).
 */
export async function lerEstado<T = unknown>(
  caminho: string,
  defaultValue: T,
  limiteTamanhoBytes = 10 * 1024 * 1024 // 10MB
): Promise<T> {
  const alvo = resolverSeguro(caminho);
  try {
    const stat = await fs.stat(alvo);
    if (stat.size > limiteTamanhoBytes) {
      // Evita leitura de arquivos inesperadamente grandes
      return defaultValue;
    }
    const conteudo = await fs.readFile(alvo, { encoding: 'utf8', flag: 'r' });
    try {
      return JSON.parse(conteudo) as T;
    } catch {
      // JSON inválido: retorna default de forma segura
      return defaultValue;
    }
  } catch (err: any) {
    if (err?.code === 'ENOENT') {
      return defaultValue;
    }
    // Erros de permissão/IO: propaga para visibilidade do chamador
    throw err;
  }
}

/**
 * Escreve JSON de forma atômica com permissões restritivas.
 */
export async function salvarEstado<T = unknown>(
  caminho: string,
  dados: T
): Promise<void> {
  const alvo = resolverSeguro(caminho);
  await garantirDiretorio(alvo);

  const tmp = `${alvo}.tmp-${process.pid}-${Date.now()}`;
  const conteudo = stringifyEstavel(dados);

  try {
    await fs.writeFile(tmp, conteudo, { encoding: 'utf8', mode: 0o600, flag: 'w' });
    // rename é atômico na maioria dos FS locais
    await fs.rename(tmp, alvo);
    // Opcional: tentativa de fsync no diretório (maior durabilidade)
    try {
      const dirFd = await (fs as any).open?.(path.dirname(alvo), fsConstants.O_DIRECTORY);
      await dirFd?.sync?.();
      await dirFd?.close?.();
    } catch {
      // Ignora se não suportado
    }
  } catch (err) {
    // Best-effort: limpa tmp em caso de falha
    try { await fs.unlink(tmp); } catch {}
    throw err;
  }
}
```

#### Uso correto em outros módulos

```ts
// src/guardian/registros.ts
import { salvarEstado, lerEstado } from '../zeladores/util/persistencia.js';

// ...
const registros = await lerEstado<RegistroIntegridade[]>(caminho, []);
await salvarEstado(destino, registros);
```

```ts
// src/relatorios/relatorio-poda.ts
import { salvarEstado } from '../zeladores/util/persistencia.js';

await salvarEstado(caminhoMd, md);     // para markdown (string)
await salvarEstado(caminhoJson, json); // para json (objeto)
```

### Dicas e Boas Práticas

- Documente helpers utilitários criados.
- Prefira helpers puros e sem efeitos colaterais, facilitando testes.
- Se helpers crescerem, mova para um módulo utilitário dedicado e registre o padrão aqui.
- Nunca duplique lógica de persistência em múltiplos arquivos.
- Para pendências, relatórios ou snapshots, use sempre os helpers centralizados.

---

## Visão Geral

Este projeto é uma CLI modular para análise, diagnóstico e manutenção de projetos, organizada em múltiplos domínios (analistas, arquitetos, zeladores, guardian, etc). O código é escrito em TypeScript com ESM.

## Estrutura Principal

- `src/cli.ts`: Entrada principal da CLI.
- `src/cli/`: Comandos individuais (ex: `comando-diagnosticar.ts`, `comando-podar.ts`).
- `src/analistas/`, `src/arquitetos/`, `src/zeladores/`, `src/guardian/`: Núcleos de lógica para análise, diagnóstico, correção e verificação.
- `src/nucleo/`: Funções centrais de execução, parsing, scanner e utilidades globais.
- `src/relatorios/`: Geração e estruturação de relatórios (sempre via helpers centralizados).
- `src/tipos/tipos.ts`: Tipos e interfaces compartilhados.
- `src/zeladores/util/`: Helpers utilitários e persistência de estado.

## Convenções e Padrões

- Helpers centralizados para persistência, pendências e relatórios.
- Aliases de importação: `@nucleo/*`, `@analistas/*`, etc (vide `tsconfig.json`).
- Tipagem: use tipos definidos em `src/tipos/tipos.ts`.
- Modularização: cada domínio com arquivos e funções separados.
- ESM puro: não use `require`; apenas `import`/`export`.
- Sem comentários removidos (`removeComments: false`).
- Molduras (blocos multi-linha): gere com `formatarBloco` via `log.bloco` e imprima com `console.log(bloco)` (sem prefixos de logger).

Exemplo:

```ts
import { log } from '@nucleo/constelacao/log';

const linhas = [
  'Tipo                   Quantidade',
  '---------------------  ----------',
  'TODO_PENDENTE           214',
];
const bloco = (log as unknown as { bloco: Function }).bloco(
  'Resumo dos tipos de problemas',
  linhas,
);
console.log(bloco); // impressão direta, sem prefixo
```

## Fluxos de Trabalho

- Build: TypeScript conforme `tsconfig.json`. Saída em `dist/`.
- Execução CLI: `node dist/cli.js <comando>` após build.
- Aliases: importe módulos usando os aliases do `tsconfig.json`.
- Testes: Vitest. Em testes `process.env.VITEST` deve impedir `process.exit`.
- Persistência: sempre via helpers centralizados.
- Branches: `develop` para desenvolvimento; `main` protegida (PR + checks).
- Pré-visualização: `npm run pre-public` monta `pre-public/` (sem publicar).
- Release manual: workflow `release-prepublic` cria Release draft anexando `pre-public.zip`.

## Cobertura e Testes (Vitest)

- Limiares (V8): linhas/declarações/funções 90%, ramos 88% (preferencialmente ≥90% em arquivos críticos da CLI).
- Priorização de ramos: adicione micro-testes para early-returns (`--scan-only`), caminhos de erro/catch e combinações de flags (verbose, compacto, guardian full-scan).
- Execução em testes: durante Vitest, `process.env.VITEST` deve desabilitar saídas que encerram o processo. Use spies em `process.exit` e restaure no teardown.
- Mocks úteis: isole formatação de terminal (chalk/width), IO (helpers de persistência) e relógio. Não faça mock de `fs` direto: apenas dos helpers (`lerEstado`/`salvarEstado`).
- Estabilidade: evite flakiness controlando flags/ambiente explicitamente (`COMPACT_MODE`, `VERBOSE`, `SCAN_ONLY`).

## Flags Recentes / Comportamentos

- `--scan-only`: somente varredura + priorização (sem técnicas mutáveis).
- `--full-scan` (guardian): ignora padrões de ignore para inspeção pontual (não persiste baseline).
- `--json`: saída estruturada em `diagnosticar` e `guardian` (consumível por CI/pipelines).

### Saída JSON e política de logs

- Em `--json`, silencie logs verbosos durante a montagem e emita apenas o JSON final; restaure o logger depois.
- Escapes Unicode: toda saída JSON deve escapar caracteres fora de ASCII básico via `\uXXXX`. Cobrir:
  - BMP não-ASCII (acentos, símbolos).
  - Pares substitutos para caracteres fora do BMP (ex.: emojis) como dois `\uXXXX`.
  - Fallback quando o code point não for identificável (`cp == null`) — retorne escape seguro.
- Guardian no JSON: quando não for executado, retorne status coerente (ex.: `"nao-verificado"`) e mantenha o shape estável.

## Linguagens / Parsing Suportado

Parsing primário (AST Babel completo): `.js`, `.jsx`, `.ts`, `.tsx`, `.mjs`, `.cjs`.

Parsing leve / heurístico (AST mínimo compat + `oraculoExtra`):

- Kotlin: `.kt`, `.kts` (símbolos `class|object|fun`).
- Java: `.java` (java-parser).
- XML: `.xml` (fast-xml-parser).
- HTML: `.html`, `.htm` (htmlparser2 DOM -> wrapper).
- CSS: `.css` (css-tree AST).
- Gradle (Groovy/KTS): `.gradle`, `.gradle.kts` (regex para plugins e deps).

Limitação: Analistas que dependem de nós Babel só atuam em linguagens suportadas pelo Babel. Demais arquivos ficam disponíveis para analistas específicos via `oraculoExtra`.

## Saída JSON (`diagnosticar --json`)

Campo `estruturaIdentificada` inclui:

- `melhores`: lista de arquétipos candidatos.
- `baseline`: snapshot salvo.
- `drift`: mudanças (alterouArquetipo, deltaConfidence, arquivos raiz novos/removidos).

Campo raiz adicional:

- `linguagens`: resumo de extensões analisadas (ex.: `{ "total": 230, "extensoes": { "ts": 120, "js": 40, "kt": 5, ... } }`), ordenado por quantidade desc.

Notas de encoding:

- Escape unicode (`\uXXXX`) para caracteres fora de ASCII básico quando `--json` for usado (mitiga artefatos de consoles Windows legados).
- Suporte a pares substitutos e caminhos de fallback seguros.

## Agregação de PARSE_ERRO

- Erros de parsing por arquivo podem ser agregados após limite configurável (`PARSE_ERRO_MAX_POR_ARQUIVO`).
- Contagem total original preservada em campo interno (`__ORACULO_PARSE_ERROS_ORIG_TOTAL__`).
- Objetivo: permitir análise de tendência sem inundar logs.
- Próximo passo: expor limites e política no README.

Observações de testes:

- Cubra casos-limite garantindo respeito ao limite por arquivo e preservação da contagem total no campo interno.

## Documentação — Fonte Única de Verdade

- Roadmap operacional: `docs/CHECKLIST.md`.
- Remoções: `ROADMAP_ITERACOES.md`, `SUGESTOES-PRIORITARIAS.md`, `JSDOC.md` (duplicados).
- Guardian: `docs/guardian.md`.
- Camadas de teste: `docs/relatorios/camadas-testes.md`.
- Performance baseline: `docs/perf/README.md`.

Qualquer novo documento estratégico deve ser referenciado no CHECKLIST.

## Exemplos de Uso de Alias

```ts
import { executar } from '@nucleo/executor';
import { analisarPadroes } from '@analistas/analista-padroes-uso';
```

## Decisões Arquiteturais

- Separação entre análise (analistas), diagnóstico (arquitetos), correção (zeladores) e verificação (guardian).
- Relatórios e persistência de estado via helpers centralizados.
- Tipos centralizados para consistência entre domínios.

### Molduras e largura de exibição

- Gere molduras multi-linha com `formatarBloco` via `log.bloco` e imprima com `console.log(bloco)`.
- Largura: cálculo dinâmico; fallback determinístico — compacto: 84 colunas; padrão: 96 colunas. Em DEV/CI sem `chalk.columns`, aplique os fallbacks.
- Logs verbosos de filtros (include/exclude) não devem quebrar molduras; em `--json` devem ser silenciados.

## Dependências e Requisitos

- Node.js 24.0.4
- TypeScript (vide `tsconfig.json`)
- Vitest para testes
- Monitoramento recomendado (Dependabot, npm-check-updates)

## Organização de Documentação

- Centralize documentação e relatórios em `docs/`.
- Ex.: `docs/RELATORIO.md`, `docs/CHECKLIST.md`.

## Checklist de Melhorias

- Atualize sempre `docs/CHECKLIST.md` com pendências, melhorias e histórico.
- Consulte o checklist antes e depois de modificações relevantes.

## Diretrizes de Engenharia Segura (adicionais)

- Nunca use `eval`, `Function` dinâmica ou desabilite verificações de tipo para contornar erros.
- Sanitizar e validar entradas de usuário; limitar tamanho/escopo de entradas e recursos.
- Evitar injeção de comando: se precisar executar processos, use `spawn` com `shell: false` e passe argumentos como lista.
- Use padrões seguros por padrão (TLS/HTTPS, headers de segurança, cookies HttpOnly/SameSite se aplicável).
- Não ampliar CORS ou permissões além do necessário.
- Registre “notas de risco” quando alterar autenticação, autorização, criptografia, armazenamento de segredos ou superfícies de rede.

## Novas Diretrizes (2025-08-16)

### Testes de Fixtures por Arquétipo
- Crie diretórios de fixtures em `tests/fixtures/estruturas/` para testar detecção de arquétipos.
- Adicione casos híbridos e de conflito de confiança.
- Testes devem simular o motor heurístico e validar identificação correta.

### Testes de Combinações de Comandos/Options
- Teste combinações principais de comandos e options da CLI.
- Garanta cobertura para casos que geram warnings/erros; crie issues para cada falha.
- Use mocks/spies para validar logs e outputs.

### Refatoração do comando-diagnosticar.ts
- Separe options em `src/cli/options-diagnosticar.ts`.
- Modularize fases do comando em funções menores.

### Registro de Datas
- Sempre registre data de finalização ao concluir itens no `CHECKLIST.md`.
- Neste arquivo, registre a data da última atualização das diretrizes.

---

Última atualização das diretrizes: 2025-08-17