#!/usr/bin/env node
/* eslint-disable no-console */
import { readFile } from 'node:fs/promises';
import { execSync } from 'node:child_process';

const files = execSync("git ls-files '*.md'", { encoding: 'utf8' })
  .split('\n').map(s => s.trim()).filter(Boolean);

const marker = /Proveni[eê]ncia e Autoria/i;

const missing = [];
for (const f of files) {
  const content = await readFile(f, 'utf8');
  const head = content.split('\n').slice(0, 30).join('\n');
  if (!marker.test(head)) missing.push(f);
}

if (missing.length) {
  console.error('Arquivos sem o aviso de Proveniência e Autoria (primeiras 30 linhas):');
  for (const m of missing) console.error('-', m);
  process.exit(2);
} else {
  console.log('Todos os .md contêm o aviso de Proveniência e Autoria.');
}