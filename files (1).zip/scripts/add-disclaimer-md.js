#!/usr/bin/env node
/* eslint-disable no-console */
import { readFile, writeFile } from 'node:fs/promises';
import { execSync } from 'node:child_process';
import path from 'node:path';

const disclaimerPath = 'docs/partials/AVISO-PROVENIENCIA.md';
const disclaimer = await readFile(disclaimerPath, 'utf8');

const files = execSync("git ls-files '*.md'", { encoding: 'utf8' })
  .split('\n').map(s => s.trim()).filter(Boolean)
  // ignore o próprio snippet e arquivos gerados
  .filter(f => f !== disclaimerPath && !f.startsWith('pre-public/'));

const marker = /Proveni[eê]ncia e Autoria/i;

for (const f of files) {
  const content = await readFile(f, 'utf8');
  const head = content.split('\n').slice(0, 30).join('\n');
  if (marker.test(head)) continue;

  const updated = `${disclaimer}\n\n${content.trimStart()}\n`;
  await writeFile(f, updated, 'utf8');
  console.log(`Inserido aviso em: ${f}`);
}
console.log('Concluído.')